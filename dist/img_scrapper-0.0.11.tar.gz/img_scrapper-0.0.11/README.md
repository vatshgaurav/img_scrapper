# img_scrapper
Python package for image scrapping from google images
