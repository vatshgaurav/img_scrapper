from src.img_scrapper import *

get_original_images("Spotify")
